# Answer frameworks

## 1. Claim-Proof-Tool-Result (default, 45-75 s)
- **Claim**: direct answer in one sentence.
- **Proof**: one real example, where and when.
- **Tool**: the named tool, method, or guideline used.
- **Result**: a number or concrete outcome, plus a one-line takeaway.

## 2. STAR+ (behavioural, 60-90 s)
Situation (10%) / Task (10%) / Action (50%, "I", not "we") / Result with number (20%) / **+ Lesson** (10%).

## 3. Think-aloud (technical or case tasks)
Restate the problem, state assumptions, outline approach, execute step by step while talking, sanity-check, state limits. Silence is worse than a half-formed spoken thought.

## 4. Concrete over hypothetical
Replace "If I were in that situation, I would..." with "In [project] I faced [X], I did [Y], and [result]." If no real example exists: "I haven't faced this directly. The closest thing is [Z]. Here is how I would handle it: [steps]."

## 5. Handling a gap honestly
"I haven't used [tool] in production. I've done [adjacent work]. Here is how I'd get productive quickly: [specific steps]." Never bluff.

## 6. Judgement and ambiguity (AI evaluation roles)
Re-read guideline > identify the ambiguity > pick the interpretation most consistent with the guideline's intent > justify in writing > flag it for review. Mention consistency and documentation.

## 7. Handling disagreement or feedback
Listen > clarify the reason > check the evidence > adapt or escalate respectfully with data. Give a real instance where feedback changed the result.

## 8. Self-introduction template (60-90 s)
Who I am now (role/status) > 2 proofs most relevant to this JD (with numbers) > why this role > one-line close. Write it in your own words; rehearse until natural, never recite.

## 9. Filler control
Replace "um/uh" with a silent breath. Start answers with the answer. End on the result, then stop.

## 10. Self-review checklist after each practice take
Did I answer in the first sentence? Specific tool? A number? Under 90 s? Any hypothetical that should have been a real example? Any claim I could not defend under 3 follow-ups?
