# Zara: what is known (with confidence)

Compiled from web research (Oct 2026). Re-search when stakes are high: the product changes quickly. Mark anything you cannot verify as Unverified in the plan.

## Identity
- **Confirmed**: Zara is an AI interviewer / recruiter agent built by micro1, used to screen candidates for its expert network and for client companies. micro1's own research paper says it runs on GPT-4o and includes practice interviews, AI-led interviews, structured feedback reports, and automated candidate query handling (RAG).
- **Likely**: Alignerr (AI data annotation/training marketplace) also uses a Zara-branded interviewer. One source credits Labelbox with developing Alignerr's Zara, which conflicts with the micro1 attribution. **Unverified**: how these relate. Treat platform as "check which one the invite email names".

## Format
- **Likely**: live, browser-based video conversation with a 3D avatar speaking in real time; no downloads; needs mic and camera. Roughly 15-40 minutes depending on client config (sources vary: 15, 18 practice, 20-30, 20-40).
- **Confirmed (micro1 paper)**: questioning branches in real time; there is a role-specific practice interview and a post-interview structured report (technical + CEFR-style soft-skill rubric) with strengths and gaps.
- **Likely**: Zara reads the resume/profile first and personalises follow-ups to what the candidate says in the intro. No two candidates get identical questions.
- **Likely**: for technical roles, may include screen-share or coding tasks.

## What is evaluated
- **Likely**: role knowledge and depth, communication clarity, structure, relevance, confidence, specificity (numbers and named tools rewarded), fit with role, and integrity.
- **Likely**: she presses on hypotheticals until something concrete appears; exaggeration is exposed through follow-ups.
- **Likely**: a human recruiter reviews the score/report; Zara does not decide alone.

## Integrity and recording
- **Confirmed (privacy notice cited by guides)**: audio, video and transcript are recorded; screen recorded for technical tasks; proctoring analytics assess integrity.
- **Unverified (one vendor blog selling a competing tool)**: response latency, gaze direction, and unusual smoothness are scored and may be flagged. Plausible but not official. Plan conservatively: look at camera, answer naturally, no second-screen reading.

## Unknowns (state these openly)
- Passing thresholds, scoring weights, and exact question banks are not published and vary per client.
- Whether feedback is given on rejection varies; micro1 says it provides reports.

## Sources used
- micro1 research paper: micro1.ai/research/zara-an-llm-based-candidate-interview-feedback-system (arXiv 2507.02869)
- redpenjobs.com guide to micro1 Zara (updated 20 Sep 2026)
- getaiwork.com Zara guide (2026)
- aitrainer.work Zara guide
- aceround.app blog on timing/integrity (vendor, treat with caution)
- Grokipedia page (Alignerr/Labelbox attribution; low reliability)
