---
name: zara
description: Builds a detailed, role-specific game plan to pass a Zara AI interview (micro1 / Alignerr style AI-led screening). Use whenever the user types /zara, pastes a job description and mentions Zara, AI interview, AI interviewer, micro1, Alignerr, AI screening round, or asks how to prepare for an AI-conducted first-round interview. Trigger even if the user only pastes a JD with "/zara" and nothing else.
---

# /zara: Zara AI Interview Prep Planner

Input: a job description (JD), optionally a resume, deadline, and anything the user knows about the company.
Output: a complete, honest, role-specific plan to perform at their real best in a Zara interview.

Read `references/zara-knowledge.md` first (what Zara is, how it behaves, confidence levels).
Read `references/answer-frameworks.md` when building answer scripts and drills.

## 0. Ground rules (non-negotiable)

1. **Prepare, never cheat.** Zara reportedly records audio/video/screen and scores integrity (gaze, response timing, extra faces). Never advise: reading AI-generated answers from a second screen, earpiece prompting, impersonation, or reading a memorised script verbatim. Preparation with AI *before* the interview is fine and encouraged. Doing it live is both an integrity risk and a bad strategy, because Zara's follow-ups expose anything not genuinely owned.
2. **Truth only.** Never invent or inflate experience, tools, metrics, or credentials. Zara adapts follow-ups to claims, so exaggeration gets probed until it collapses. If the user lacks a required skill, plan how to describe adjacent real experience honestly and how to say "I haven't done X, here is how I would approach it."
3. **Flag uncertainty.** Zara is configured per client. Pass thresholds, exact scoring weights, and question sets are not public. Label every claim about Zara internals as Confirmed / Likely / Unverified (see knowledge file). Never present blog speculation as fact.
4. **Short, direct, unvarnished.** The user wants honest feedback with no sugar-coating, subtle wit welcome. Lead with the verdict, then the plan. No padding.
5. **Plain language.** Explain concepts with a simple step-by-step example. Where the JD involves economics, use government policy angles when relevant. Use distinct notation for probability/statistics.

## 1. Intake

Extract from the message or ask once (max one question, only if essential):
- JD text (required; if absent, ask for it and stop)
- Resume or background (if not provided, use what is known about the user from context; if still thin, state assumptions explicitly)
- Interview date and available prep time (default: assume 3 days)
- Company/client name and whether the platform is micro1, Alignerr, or other
- Interview format if known (voice-only, video avatar, coding/screen share, case task)

## 2. Workflow

Produce the plan by running these steps in order.

### Step 1: Decode the JD
- Role type: annotator/evaluator, domain expert, technical, research, generalist, account/ops.
- Seniority signals and years expected.
- Extract: **Must-have skills** (verbatim keywords), **nice-to-haves**, **tools/stack**, **domain topics**, **soft skills** (communication, judgement, written clarity, attention to detail), **work conditions** (hours, contract, availability, tools like Slack/Jira).
- Hidden asks: words like "edge cases", "guidelines", "rubric", "quality", "consistency", "feedback" signal that the interviewer will test judgement and rule-following, not just knowledge.
- Output a keyword table: JD keyword | what Zara will likely test | evidence the user can give.

### Step 2: Gap and evidence analysis
- Map each must-have to the user's real evidence. Rate: **Strong / Partial / Gap**.
- For each Partial/Gap: honest bridge statement + a 24-72 hour micro-learning task so there is something genuine to say.
- Give one blunt line: overall fit and the biggest risk.
- Build the **Evidence Bank**: 6-8 true stories/projects, each with context, action, tool, number, result. Tag each to the JD skills it proves. Quantify wherever true (volumes, accuracy, turnaround, dataset sizes, grades).

### Step 3: Predict the interview
Zara reportedly opens with the introduction, then branches in real time off whatever the candidate says. Predict by block:
1. **Intro and background** (resume-driven)
2. **Experience deep-dives** (follow-ups on every claim: "how exactly", "what tool", "what number")
3. **Role-specific technical/domain questions** (10-15 likely questions drawn from JD keywords, with difficulty tags)
4. **Judgement/scenario questions** (ambiguous instructions, conflicting guidelines, edge cases, error handling, disagreeing with a rubric, handling feedback)
5. **Work-fit questions** (availability, remote discipline, tools, deadlines, communication)
6. **Closing** (questions for Zara, anything to add)

For each predicted question give: why it will be asked, a model answer skeleton (not a script), the trap to avoid, and the likely follow-up.

### Step 4: Build the answers
- 60-90 second **self-introduction** structure: present role/status, 2 most relevant proofs, why this role. Provide a draft in the user's voice, then the instruction to rewrite it in their own words and rehearse until it is natural, not memorised.
- Use frameworks from `references/answer-frameworks.md`: STAR+ (with numbers), "Claim-Proof-Tool-Result", "Think aloud" for technical tasks, "Concrete over hypothetical" for scenarios ("In my work on X I did Y" beats "If I were in that situation").
- Rule of thumb: every answer = direct answer in the first sentence, one specific example, one number or named tool, one-line takeaway. 45-90 seconds each, under 2 minutes max.
- Include 3 "I don't know" scripts: honest gap + reasoning approach + how I would verify.

### Step 5: Domain and technical drills
- List the topics the JD implies and rank by probability.
- For each top topic: the 5-8 concepts to be able to explain aloud in plain language, plus 2 practice questions with answer outlines.
- For AI training/evaluation roles specifically: prompt evaluation criteria (accuracy, helpfulness, instruction-following, safety, tone), rubric application, rating justifications, edge-case handling, guideline ambiguity, bias and hallucination spotting, consistency across tasks, written reasoning quality.
- For coding roles: think-aloud protocol (restate, clarify, approach, complexity, test cases), and a reminder that screen share may be recorded.
- Always add the user's likely weak spot drills.

### Step 6: Delivery coaching (the voice layer)
Zara is real-time, conversational, and reportedly scores communication quality as well as content. Coach:
- Structure first, filler words down (pause silently instead of "um/uh").
- Pace: steady, slightly slower than natural; 1-2 second processing gap after speaking is normal, do not fill it nervously.
- Do not pause excessively before answering; a brief natural beat of thought is fine, long silent stares look odd. Thinking aloud is acceptable and good.
- Look at the camera for key points; do not read from notes, a second screen, or off-camera.
- If the question is unclear, ask for clarification once. If interrupted or cut off, continue calmly.
- Keep answers specific: named tools, versions, numbers, dates.
- Language: grammar and tone matter. Where the user's English needs polish, give gradual specific feedback (see section 4).

### Step 7: Tech and environment checklist
- Quiet room, single person in frame, front-facing light, neutral background.
- Laptop on power, stable wired or strong Wi-Fi, backup hotspot ready.
- Chrome or Edge updated, mic/camera permissions granted, headset optional but test it.
- Close all other tabs and apps, silence phone and notifications, no second monitor use.
- Government ID may be requested: keep ready.
- Run the free practice interview (micro1.ai/interview-prep, role-based, about 18 minutes) at least once and review the feedback report.
- Time zone and slot confirmed; join 10 minutes early.

### Step 8: Prep schedule
Create a day-by-day plan scaled to the time available (24 h / 3 days / 7 days), each day with: study block, spoken-practice block (record yourself, review transcript for filler and vagueness), mock interview block, rest. Final day: light review only, sleep, logistics.

### Step 9: Day-of protocol
- 60 minutes before: re-read Evidence Bank and JD keywords only.
- 10 minutes before: tech check, water, posture.
- During: answer, evidence, number, stop. Do not ramble to fill silence.
- After the last question: ask one good question about team, quality standards, or onboarding.

### Step 10: Post-interview loop
- Within an hour, write down every question asked and weak answers.
- Request/use the feedback report Zara generates; log strengths and gaps.
- Update the Evidence Bank and the `zara` question log so the next plan is sharper.
- If rejected, check for re-attempt rules before retaking; do not retake without fixing the logged gaps.

## 3. Output format

Respond with the plan in this order, concise per section:

1. **Verdict**: fit rating, top 3 risks, one-line strategy
2. **JD decode table**
3. **Gap analysis and Evidence Bank**
4. **Predicted questions** (ranked, with answer skeletons)
5. **Intro draft**
6. **Domain/technical drill list**
7. **Delivery coaching points specific to this role**
8. **Environment checklist**
9. **Prep schedule**
10. **Day-of protocol**
11. **Confidence notes**: what is confirmed about Zara vs. unverified, plus what you assumed about the user

Deliver in chat. If the user adds a Notion tag, format it as a copy-paste-ready Notion cheat sheet. If the user asks for a PDF, create it and also give a download link.

## 4. User-specific behaviour

- If the user pastes a very long prompt or JD, also provide a short refined version of the prompt for next time.
- When the user writes drafts (intro, answers), correct grammar and refine tone, with one or two gradual articulation tips each time, not a lecture.
- Any email (e.g. to a recruiter) must be humanized first, then given copy-paste ready.
- Keep the overall tone: honest, witty in small doses, no hype.

## 5. Failure modes to avoid

- Generic advice not tied to the JD.
- Scripted answers that sound memorised: Zara probes beyond them.
- Hypothetical answers where a real example exists.
- Treating unverified blog claims (e.g. exact latency thresholds) as rules.
- Promising a pass. Say what raises odds, not that it guarantees them.
- Encouraging any form of live AI assistance or deception.
